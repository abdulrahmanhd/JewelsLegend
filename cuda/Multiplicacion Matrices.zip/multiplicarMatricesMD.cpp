#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "stdafx.h"

const int filas = 2;
const int columnas = 2;

int multiplicarMatriz(int **matriza, int **matrizb, int **matrizr){
	int temporal, i, j, k = 0;
	for (i = 0; i < filas; i++){//i para las filas de la matriz resultante
		for (k = 0; k < columnas; k++){ // k para las columnas de la matriz resultante
			temporal = 0;
			for (j = 0; j < 2; j++){ //j para realizar la multiplicacion de los elementos   de la matriz
				temporal += matriza[i][j] * matrizb[j][k];
				matrizr[i][k] = temporal;
			}
		}
	}
	return 0;
}

int printMatriz(int **matriz){
	int i, j = 0;
	for (i = 0; i < 2; i++){
		for (j = 0; j < 2; j++){
			if (j != 1)
				std::cout << matriz[i][j] << " ";
			else
				std::cout << matriz[i][j] << "\n";
		}
	}
	return 0;
}

int introducirDatosMatriz(int **matriz){
	int i, j = 0;
	for (i = 0; i < filas; i++){
		for (j = 0; j < columnas; j++){
			std::cout << "Introduce el numero de la posicion (" << i << "," << j << "): ";
			std::cin >> matriz[i][j];
		}
	}
	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{

	int **matriza;
	int **matrizb;
	int **matrizResult;

	//Reservamos memoria para las matrices
	int i = 0;
	matriza = (int**)malloc(filas*sizeof(int*));
	for (i = 0; i < columnas; i++){
		matriza[i] = (int*)malloc(columnas*sizeof(int));
	}

	matrizb = (int**)malloc(filas*sizeof(int*));
	for (i = 0; i < columnas; i++){
		matrizb[i] = (int*)malloc(columnas*sizeof(int));
	}

	matrizResult = (int**)malloc(filas*sizeof(int*));
	for (i = 0; i < columnas; i++){
		matrizResult[i] = (int*)malloc(columnas*sizeof(int));
	}

	//Pedimos los datos de las matrices que queremos multiplicar
	std::cout << "Matriz A" << "\n";
	introducirDatosMatriz(matriza);
	std::cout << "\n" << "Matriz B" << "\n";
	introducirDatosMatriz(matrizb);

	//Mostramos las dos matrices
	std::cout << "\n" << "Matriz A" << "\n";
	printMatriz(matriza);
	std::cout << "\n" << "Matriz B" << "\n";
	printMatriz(matrizb);

	//Calculamos la matriz resultante y la mostramos
	multiplicarMatriz(matriza, matrizb, matrizResult);
	std::cout << "\n" << "Matriz Resultado" << "\n";
	printMatriz(matrizResult);

	free(matriza);
	free(matrizb);
	free(matrizResult);

	system("pause");

	return 0;
}