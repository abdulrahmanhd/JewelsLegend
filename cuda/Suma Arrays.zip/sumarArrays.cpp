#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include "stdafx.h"

const int tamano = 5;

int sumarArrays(int *matriza, int *matrizb, int *matrizr){
	int i;
	for (i = 0; i < tamano; i++){//i para las filas de la matriz resultante
		 matrizr[i] = matriza[i] + matrizb[i];	
	}
	return 0;
}

int printArray(int *matriz){
	int i;
	for (i = 0; i < tamano; i++){
				std::cout << matriz[i];

	}
	return 0;
}

int introducirDatosArray(int *matriz){
	int i, j = 0;
	for (i = 0; i < tamano; i++){
			std::cout << "Introduce el numero de la posicion (" << i << "): ";
			std::cin >> matriz[i];
		}
	
	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{

	int *matriza;
	int *matrizb;
	int *matrizResult;

	//Reservamos memoria para las matrices
	int i = 0;
	matriza = (int*)malloc(tamano*sizeof(int*));
	

	matrizb = (int*)malloc(tamano*sizeof(int*));

	matrizResult = (int*)malloc(tamano*sizeof(int*));
	

	//Pedimos los datos de las matrices que queremos multiplicar
	std::cout << "Array A" << "\n";
	introducirDatosArray(matriza);
	std::cout << "\n" << "Array B" << "\n";
	introducirDatosArray(matrizb);

	//Mostramos las dos matrices
	std::cout << "\n" << "Array A" << "\n";
	printArray(matriza);
	std::cout << "\n" << "Array B" << "\n";
	printArray(matrizb);

	//Calculamos la matriz resultante y la mostramos
	sumarArrays(matriza, matrizb, matrizResult);
	std::cout << "\n" << "Array Resultado" << "\n";
	printArray(matrizResult);

	free(matriza);
	free(matrizb);
	free(matrizResult);

	system("pause");

	return 0;
}